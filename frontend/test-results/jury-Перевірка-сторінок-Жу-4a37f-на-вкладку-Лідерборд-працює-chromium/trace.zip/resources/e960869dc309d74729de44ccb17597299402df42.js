(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_next_dist_06gz65m._.js","static/chunks/[next]_internal_font_google_inter_6df552e6_module_0glos86.css"],
    source: "dynamic"
});
